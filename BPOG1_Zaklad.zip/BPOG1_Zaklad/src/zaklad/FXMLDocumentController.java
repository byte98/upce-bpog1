package zaklad;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

/**
 *
 * @author peve
 */
public class FXMLDocumentController implements Initializable {
          
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
